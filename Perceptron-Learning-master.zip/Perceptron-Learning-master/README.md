# Perceptron-Learning
Implement Perceptron Learning algorithm for 2 or more linearly separable classes.
Two ways of implementing perceptron learning for multiple classes:

1.One against One(p3_1v1.py):
  In this method each class is trained against other class and using voting scheme, a testing data is assigned a class.
2.One against All(p3_1vAll.py):
  In this method each class is trained against all other classes and a testing data is assigned to class for which discriminat function returns negative value,

